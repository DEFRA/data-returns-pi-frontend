const fs = require("fs");
const parseString = require('xml2js').parseString;
const base64 = require('base-64');
const queryString = require('query-string');

fs.readFile("burp.all.xml", "utf8", function(err, data) {

    parseString(data, function (err, result) {

        const items = result.items.item;

        const obj = items.filter(r => !r.path[0].includes('/public')).map((r) => {
            return {
                path: r.path[0],
                status: Number.parseInt(r.status[0]),
                method: r.method[0],
                request: base64.decode(r.request["0"]._).split('\r\n'),
                response: base64.decode(r.response["0"]._).split('\r\n')
            };
        });

        let obj2 = obj.map((r) => {
            const result = {
                path: r.path,
                status: r.status,
                method: r.method,
            };

            if (r.method === 'POST') {
                if (r.request[r.request.length - 1]) {
                    result.payload = queryString.parse(r.request[r.request.length - 1]);
                } else {
                    result.payload = {};
                }
            }
            if (r.status === 302) {
                result.redirect = r.response.find(h => h.includes('location:')).substr(10);
            }

            return result;
        });

        console.log(JSON.stringify(obj2, null, 4));
    });

});

